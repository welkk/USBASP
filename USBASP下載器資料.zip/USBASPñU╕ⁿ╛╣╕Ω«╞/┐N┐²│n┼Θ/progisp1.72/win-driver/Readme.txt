With WinAVR version 20080512 or greater, please use libusb_0.1.12.1.
Use libusb_0.1.10.1 with older WinAVR versions.
